using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]  // enforces dependency on character controller
[AddComponentMenu("Control Script/FPS Input")]  // add to the Unity editor's component menu
public class FPSInput : MonoBehaviour
{
    // normal walking speed
    public float speed = 6.0f;
    // sprint speed
    public float sprintSpeed = 7.0f;
    // gravity setting
    public float gravity = -9.8f;

    // reference to the character controller
    private CharacterController charController;

    // reference to the stamina script
    private Stamina stamina;

    // Start is called before the first frame update
    void Start()
    {
        // get the character controller component
        charController = GetComponent<CharacterController>();
        // get the stamina component
        stamina = GetComponent<Stamina>();
    }

    // Update is called once per frame
    void Update()
    {
        float currentSpeed = speed;

        // Check if the player can sprint and is holding LeftShift
        if (Input.GetKey(KeyCode.LeftShift) && stamina.CanSprint())
        {
            currentSpeed = sprintSpeed; // Increase speed to sprint
            stamina.isSprinting = true; // Enable sprint in stamina script
        }
        else
        {
            stamina.isSprinting = false; // Disable sprint when not holding LeftShift or out of stamina
        }

        // Get movement input based on WASD keys
        float deltaX = Input.GetAxis("Horizontal") * currentSpeed;
        float deltaZ = Input.GetAxis("Vertical") * currentSpeed;

        // Combine inputs into a movement vector
        Vector3 movement = new Vector3(deltaX, 0, deltaZ);

        // Ensure consistent movement speed, even when moving diagonally
        movement = Vector3.ClampMagnitude(movement, currentSpeed);

        // Apply gravity
        movement.y = gravity;

        // Make the movement framerate-independent
        movement *= Time.deltaTime;

        // Convert from local space to world space
        movement = transform.TransformDirection(movement);

        // Pass the movement to the character controller
        charController.Move(movement);
    }
}
