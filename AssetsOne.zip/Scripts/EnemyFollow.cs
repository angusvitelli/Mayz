using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyFollow : MonoBehaviour
{
    public Transform player;
    public float speed = 5f;
    public float followRange = 10f;
    public float rotationSpeed = 5f;
    public Transform[] patrolPoints;
    public float patrolSpeed = 3f;
    public float patrolWaitTime = 2f;
    public AudioClip followSound; 

    private int currentPoint = 0;
    private NavMeshAgent agent;
    private bool isFollowing = false;
    private bool waiting = false;
    private AudioSource audioSource;

    public float minEnemyDistance = 3f;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        agent.autoBraking = false; // Prevent stopping between waypoints
        audioSource = GetComponentInChildren<AudioSource>();
        GoToNextPatrolPoint();
    }

    void Update()
    {
        if (player != null)
        {
            float distanceToPlayer = Vector3.Distance(transform.position, player.position);

            if (distanceToPlayer <= followRange)
            {
                if (!isFollowing) // Play the sound only when AI starts following
                {
                    audioSource.PlayOneShot(followSound);
                }

                isFollowing = true;
                FollowPlayer();
            }
            else
            {
                isFollowing = false;
                PatrolArea();
            }
        }
    }

    void GoToNextPatrolPoint()
    {
        if (patrolPoints.Length == 0)
            return;

        agent.speed = patrolSpeed; // Set patrol speed
        agent.destination = patrolPoints[currentPoint].position;
        currentPoint = (currentPoint + 1) % patrolPoints.Length;
    }

    bool IsAnotherEnemyTooClose()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, minEnemyDistance);
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.CompareTag("Enemy") && hitCollider.gameObject != this.gameObject)
            {
                return true; // Another enemy is too close
            }
        }
        return false; // No nearby enemies
    }

    IEnumerator WaitAndGoToNextPoint()
    {
        waiting = true;
        yield return new WaitForSeconds(patrolWaitTime); // Wait at the current patrol point
        waiting = false;
        GoToNextPatrolPoint();
    }

    void PatrolArea()
    {
        if (!waiting && !agent.pathPending && agent.remainingDistance < 0.5f)
        {
            if (IsAnotherEnemyTooClose())
            {
                // Optionally wait or move to a different point if another enemy is too close
                StartCoroutine(WaitAndGoToNextPoint());
            }
            else
            {
                GoToNextPatrolPoint();
            }
        }
    }

    void FollowPlayer()
    {
        Vector3 direction = player.position - transform.position;
        direction.Normalize();

        Quaternion lookRotation = Quaternion.LookRotation(direction);
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed);

        agent.speed = speed;
        agent.destination = player.position;
    }
}
