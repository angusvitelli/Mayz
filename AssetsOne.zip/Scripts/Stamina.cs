using UnityEngine;
using UnityEngine.UI; // Add this to use UI components

public class Stamina : MonoBehaviour
{
    public float maxStamina = 10f;
    public float currentStamina;
    public float staminaDrain = 5f;
    public float staminaRegen = 1f;
    public bool isSprinting = false;

    public Slider staminaSlider;

    void Start()
    {
        currentStamina = maxStamina;
        staminaSlider.maxValue = maxStamina;
        staminaSlider.value = currentStamina; 
    }

    void Update()
    {
        if (isSprinting)
        {
            currentStamina -= staminaDrain * Time.deltaTime;
            if (currentStamina <= 0)
            {
                currentStamina = 0;
                isSprinting = false;
            }
        }
        else if (currentStamina < maxStamina)
        {
            currentStamina += staminaRegen * Time.deltaTime;
        }

        currentStamina = Mathf.Clamp(currentStamina, 0, maxStamina);
        staminaSlider.value = currentStamina; // Update sprint slider
    }

    public bool CanSprint()
    {
        return currentStamina > 0;
    }
}
