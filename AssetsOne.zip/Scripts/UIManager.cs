using System.Collections;
using UnityEngine;
using TMPro;

public class UIManager : MonoBehaviour
{
    public TextMeshProUGUI infoText;
    public float messageDuration = 3f;
    public float fadeDuration = 2f;
    public string FlashlightTag = "Flashlight";
    public CanvasGroup canvasGroup;
    private GameObject FlashLight;

    public GameObject lightMarker;

    void Start()
    {
        FlashLight = GameObject.FindWithTag(FlashlightTag);
        if (canvasGroup != null)
        {
             canvasGroup.alpha = 0f;
        }
        
    }

    public IEnumerator FadeInThenOut()
    {
        yield return StartCoroutine(FadeInText());
        if (infoText != null && infoText.text == "Press E to pick up the flashlight.")
        {
            if (FlashLight != null && !FlashLight.activeSelf) //Checks if Flashlight is not picked up
            {
                yield return StartCoroutine(FadeOutText()); //Fade out text when Flashlight is picked up
            }
            else
            {

            }
        }
    }

    public void UpdateInfoText(string message)
    {
        if (infoText != null)
        {
            infoText.text = message;
            StartCoroutine(FadeInThenOut());
        }
        else
        {
            Debug.LogError("UIManager infoText reference is not set.");
        }
    }

    public void UpdateInfoTextForToggle(string message)
    {
        if (infoText != null)
        {
            infoText.text = message;
            StartCoroutine(FadeInThenOut());
            StartCoroutine(HideUIManagerAfterDelay(4f));
        }
        else
        {
            Debug.LogError("UIManager infoText reference is not set.");
        }
    }

    private IEnumerator FadeInText()
    {
        float elapsedTime = 0f;
        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.deltaTime;
            canvasGroup.alpha = Mathf.Clamp01(elapsedTime / fadeDuration);
            yield return null;
        }
        canvasGroup.alpha = 1f;
    }

    private IEnumerator FadeOutText()
    {
        float elapsedTime = 0f;
        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.deltaTime;
            canvasGroup.alpha = Mathf.Clamp01(1 - (elapsedTime / fadeDuration));
            yield return null;
        }
        canvasGroup.alpha = 0f;
    }

    private IEnumerator HideUIManagerAfterDelay(float delay)
    {
        StartCoroutine(FadeOutText());
        yield return new WaitForSeconds(delay);
        infoText.gameObject.SetActive(false); // Turn off text
        lightMarker.gameObject.SetActive(false); //Turn off light
    }

}
